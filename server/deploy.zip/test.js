require('dotenv').config();

const testData = {
    name: "Test User",
    email: "test@example.com",
    phone: "1234567890",
    area: "San Diego",
    message: "This is a test message"
};

async function checkPaths() {
    const baseUrl = 'https://academease-contact-dherfjbsb7csh7c6.westus-01.azurewebsites.net';
    const paths = [
        '/',
        '/api/send-email'
    ];

    for (const path of paths) {
        try {
            const response = await fetch(baseUrl + path, {
                method: path === '/' ? 'GET' : 'OPTIONS',
                headers: {
                    'Accept': 'application/json'
                }
            });
            console.log(`📍 Path ${path}:`);
            console.log(`  Status: ${response.status} ${response.statusText}`);
            console.log('  Headers:', Object.fromEntries([...response.headers]));
        } catch (error) {
            console.error(`❌ Path ${path} error:`, error.message);
        }
    }
}

async function testEmailEndpoint() {
    try {
        // Check available paths first
        console.log('🔍 Checking API paths...');
        await checkPaths();

        const apiUrl = 'https://academease-contact-dherfjbsb7csh7c6.westus-01.azurewebsites.net/api/send-email';
        console.log('\n📤 Sending test request to:', apiUrl);
        console.log('Test data:', testData);

        const response = await fetch(apiUrl, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Accept': 'application/json'
            },
            body: JSON.stringify(testData)
        });

        console.log('\n📥 Response Status:', response.status, response.statusText);
        console.log('Response Headers:', Object.fromEntries([...response.headers]));
        
        const responseText = await response.text();
        console.log('\n📄 Raw response:', responseText);

        try {
            const data = JSON.parse(responseText);
            if (response.ok) {
                console.log('\n✅ Test successful!');
                console.log('Response:', data);
            } else {
                console.log('\n❌ Test failed!');
                console.log('Status:', response.status);
                console.log('Error:', data);
            }
        } catch (e) {
            console.log('\n❌ Test failed!');
            console.log('Status:', response.status);
            console.log('Raw response:', responseText);
        }
    } catch (error) {
        console.error('\n❌ Error running test:', error.message);
        console.error('Stack:', error.stack);
    }
}

// Run test
testEmailEndpoint();